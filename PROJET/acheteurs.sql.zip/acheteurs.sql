-- phpMyAdmin SQL Dump
-- version 4.9.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 15, 2020 at 02:52 PM
-- Server version: 5.7.26
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `ebayece`
--

-- --------------------------------------------------------

--
-- Table structure for table `acheteurs`
--

CREATE TABLE `acheteurs` (
  `IDAcheteur` int(11) NOT NULL,
  `login` varchar(55) NOT NULL,
  `pwd` varchar(55) NOT NULL,
  `Nom` varchar(55) NOT NULL,
  `Prenom` varchar(55) NOT NULL,
  `email` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `acheteurs`
--

INSERT INTO `acheteurs` (`IDAcheteur`, `login`, `pwd`, `Nom`, `Prenom`, `email`) VALUES
(1, 'loulou92', 'azerty', 'Gilles', 'Gilles', 'gilles@free.fr');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acheteurs`
--
ALTER TABLE `acheteurs`
  ADD PRIMARY KEY (`IDAcheteur`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acheteurs`
--
ALTER TABLE `acheteurs`
  MODIFY `IDAcheteur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
